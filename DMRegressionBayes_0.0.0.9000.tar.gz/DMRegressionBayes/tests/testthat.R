library(testthat)
library(DMRegressionBayes)

test_check("DMRegressionBayes")
