library(testthat)
library(DMRegressionFreq)

test_check("DMRegressionFreq")
