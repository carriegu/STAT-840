#' @keywords internal
#' @import TMB
#' @import Rcpp
#' @import RcppEigen
#' @import dirmult
#' @import optimCheck
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
## usethis namespace: end
NULL
